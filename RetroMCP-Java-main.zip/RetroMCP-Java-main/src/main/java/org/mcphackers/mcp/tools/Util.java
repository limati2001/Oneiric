package org.mcphackers.mcp.tools;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.mcphackers.mcp.MCP;
import org.mcphackers.mcp.tasks.mode.TaskParameter;

public abstract class Util {
	public static final ExecutorService SINGLE_THREAD_EXECUTOR = Executors.newSingleThreadExecutor();
	public static final Map<String, Integer> javaToJavaVersion = new HashMap<>();

	public static int runCommand(String[] cmd, Path dir, boolean killOnShutdown) throws IOException {
		ProcessBuilder procBuilder = new ProcessBuilder(cmd);
		if (dir != null) {
			procBuilder.directory(dir.toAbsolutePath().toFile());
		}
		Process proc = procBuilder.start();
		Thread hook = new Thread(proc::destroy);
		if (killOnShutdown) {
			Runtime.getRuntime().addShutdownHook(hook);
		}
		BufferedReader err = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
		BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
		Thread stderr = new Thread(() -> {
			String line;
			try {
				while ((line = err.readLine()) != null) {
					System.out.println("Minecraft STDERR: " + line);
				}
			} catch (IOException ignored) {
				// we don't really care what happens here
			}

		});
		Thread stdout = new Thread(() -> {
			String line;
			try {
				while ((line = in.readLine()) != null) {
					System.out.println(line);
				}
			} catch (IOException ignored) {
				// we don't really care what happens here
			}
		});
		stdout.start();
		stderr.start();
		try {
			proc.waitFor();
		} catch (InterruptedException e) {
			throw new RuntimeException("thread interrupted while runCommand was waiting for a process to finish", e);
		}
		in.close();
		err.close();

		if (killOnShutdown) {
			Runtime.getRuntime().removeShutdownHook(hook);
		}
		return proc.exitValue();
	}

	public static void runCommand(String[] cmd) throws IOException {
		ProcessBuilder procBuilder = new ProcessBuilder(cmd);
		procBuilder.start();
	}

	public static void copyToClipboard(String text) {
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(text), null);
	}

	public static Thread operateOnThread(Runnable function) {
		Thread thread = new Thread(function);
		thread.start();
		return thread;
	}

	public static Future<?> enqueueRunnable(Runnable function) {
		return SINGLE_THREAD_EXECUTOR.submit(function);
	}

	public static void openUrl(String url) {
		try {
			if (Objects.requireNonNull(OS.getOs()) == OS.linux) {
				new ProcessBuilder("/usr/bin/env", "xdg-open", url).start();
			} else {
				if (Desktop.isDesktopSupported()) {
					Desktop desktop = Desktop.getDesktop();
					desktop.browse(new URI(url));
				}
			}
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		} catch (URISyntaxException ex) {
			throw new IllegalArgumentException(ex);
		}
	}

	public static byte[] readAllBytes(InputStream inputStream) throws IOException {
		final int bufLen = 4 * 0x400; // 4KB
		byte[] buf = new byte[bufLen];
		int readLen;
		IOException exception = null;

		try {
			try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
				while ((readLen = inputStream.read(buf, 0, bufLen)) != -1)
					outputStream.write(buf, 0, readLen);

				return outputStream.toByteArray();
			}
		} catch (IOException e) {
			exception = e;
			throw e;
		} finally {
			if (exception == null) inputStream.close();
			else try {
				inputStream.close();
			} catch (IOException e) {
				exception.addSuppressed(e);
			}
		}
	}

	public static String getMD5(Path file) throws IOException {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] digest = getDigest(md, file);

			StringBuilder sb = new StringBuilder();
			for (byte bite : digest) {
				sb.append(String.format("%02x", bite & 0xff));
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new IOException(e);
		}
	}

	public static String getSHA1(Path file) throws IOException {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-1");
			byte[] digest = getDigest(md, file);

			StringBuilder sb = new StringBuilder();
			for (byte bite : digest) {
				sb.append(Integer.toString((bite & 255) + 256, 16).substring(1).toLowerCase());
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new IOException(e);
		}
	}

	public static byte[] getDigest(MessageDigest md, Path file) {
		try (InputStream fs = Files.newInputStream(file)) {
			BufferedInputStream bs = new BufferedInputStream(fs);
			byte[] buffer = new byte[1024];
			int bytesRead;

			while ((bytesRead = bs.read(buffer, 0, buffer.length)) != -1) {
				md.update(buffer, 0, bytesRead);
			}
			return md.digest();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return new byte[]{};
	}

	public static String firstUpperCase(String s) {
		if (s == null) {
			return null;
		}
		if (s.length() <= 1) {
			return s.toUpperCase();
		} else {
			return Character.toUpperCase(s.charAt(0)) + s.substring(1);
		}
	}

	public static String convertFromEscapedString(String s) {
		return s.replace("\\n", "\n").replace("\\t", "\t");
	}

	public static String convertToEscapedString(String s) {
		return s.replace("\n", "\\n").replace("\t", "\\t");
	}

	public static String getJava() {
		return System.getProperties().getProperty("java.home") + File.separator + "bin" + File.separator + "java";
	}

	public static String getJavac(MCP mcp) {
		String javaHome = mcp.getOptions().getStringParameter(TaskParameter.JAVA_HOME);
		String defaultJavaCompiler = System.getProperties().getProperty("java.home") + File.separator + "bin" + File.separator + "javac";

		// Returns path to custom Java compiler
		if (!javaHome.isEmpty()) {
			return javaHome + File.separator + "bin" + File.separator + "javac";
		}
		return defaultJavaCompiler;
	}

	public static int getJavaVersion(MCP mcp) {
		String defaultJavaHome = getJava();
		String customJavaHome = mcp.getOptions().getStringParameter(TaskParameter.JAVA_HOME);

		// Use custom Java compiler
		if (!customJavaHome.isEmpty()) {
			if (javaToJavaVersion.containsKey(customJavaHome)) {
				return javaToJavaVersion.get(customJavaHome);
			}

			Path javacPath = Paths.get(mcp.getOptions().getStringParameter(TaskParameter.JAVA_HOME)).resolve("bin").resolve("javac");
			String javac = javacPath.toString();


			if (!javac.isEmpty() && javaToJavaVersion.containsKey(javac)) {
				return javaToJavaVersion.get(javac);
			}

			if (Files.exists(javacPath)) {
				// This is a hack...
				int javaVersion;
				if (!Files.exists(javacPath)) {
					javaVersion = 6;
					javaToJavaVersion.put(customJavaHome, javaVersion);
					return javaVersion;
				}

				String tempDirPath = System.getProperty("java.io.tmpdir");

				// Write and compile a temporary Java file, then use ASM to read the default class file
				// version.
				try {
					Path tempJavaSrc = Files.createTempFile("retromcp-javac-check-", ".java");
					Path tempJavaOut = tempJavaSrc.getParent().resolve("Main.class");
					try (BufferedWriter writer = Files.newBufferedWriter(tempJavaSrc)) {
						writer.write("class Main { }\n");
					}

					// Compile tempJavaSrc using the set javaHome
					List<String> cmd = new ArrayList<>();
					cmd.add(javacPath.toString());
					cmd.add(tempJavaSrc.toAbsolutePath().toString());
					cmd.add("-d");
					cmd.add(tempDirPath);

					int exitCode = Util.runCommand(cmd.toArray(new String[]{}), Paths.get(tempDirPath), true);
					if (exitCode != 0) {
						throw new RuntimeException("Failed to compile a test program with: " + javac);
					}

					if (!Files.exists(tempJavaOut)) {
						throw new IllegalStateException("Test program could not be found at the location it was supposed to!");
					}

					// Read class version from class
					int classVersion = ClassUtils.getClassVersion(tempJavaOut) - 45;
					javaToJavaVersion.put(customJavaHome, classVersion);
					return ClassUtils.getSourceFromClassVersion(classVersion);
				} catch (IOException ignored) {
				}
			}
		} else {
			if (javaToJavaVersion.containsKey(defaultJavaHome)) {
				return javaToJavaVersion.get(defaultJavaHome);
			}

			String javaVersion = System.getProperty("java.version");
			String[] versionParts = javaVersion.split("\\.");
			int versionNumber = Integer.parseInt(versionParts[0]);

			if (versionNumber < 9) {
				versionNumber = Integer.parseInt(versionParts[1]);
			} else {
				versionNumber = Integer.parseInt(versionParts[0]);
			}
			javaToJavaVersion.put(defaultJavaHome, versionNumber);
			return versionNumber;
		}
		return 8;
	}

	@SuppressWarnings("unchecked")
	public static <T extends Throwable> void sneakyThrow(Throwable t) throws T {
		throw (T) t;
	}

	public static void throwExceptionInIDE(Throwable t) {
		if (MCP.IS_RUNNING_IN_IDE) {
			sneakyThrow(t);
		}
	}
}
